from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time

keyword = input("Enter product keyword (e.g., laptop, headphones): ").strip().replace(" ", "+")
url = f"https://www.flipkart.com/search?q={keyword}"

options = Options()
options.add_argument("--headless")
driver = webdriver.Chrome(options=options)
driver.get(url)

# Close popup if exists
try:
    driver.find_element(By.XPATH, "//button[contains(text(),'✕')]").click()
    time.sleep(1)
except:
    print("No login popup.")

time.sleep(2)

products = []
cards = driver.find_elements(By.CSS_SELECTOR, "div._13oc-S")

for card in cards:
    try:
        name = card.find_element(By.CSS_SELECTOR, "div._4rR01T").text
        price = card.find_element(By.CSS_SELECTOR, "div._30jeq3").text.replace("₹", "").replace(",", "")
        try:
            rating = card.find_element(By.CSS_SELECTOR, "div._3LWZlK").text
        except:
            rating = "N/A"
        products.append({
            "Product Name": name,
            "Price": price,
            "Rating": rating
        })
    except:
        continue

driver.quit()

df = pd.DataFrame(products)
print(df)

df.to_csv("flipkart_products.csv", index=False)
print("\n Saved to flipkart_products.csv")
