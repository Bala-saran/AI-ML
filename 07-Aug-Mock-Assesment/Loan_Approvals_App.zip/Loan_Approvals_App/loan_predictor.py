import streamlit as st

st.title("Loan Approval Predictor")

st.markdown(" Enter Applicant Details:")

credit_score = st.selectbox("Credit Score", ["Good", "Average", "Poor"])
employment_type = st.selectbox("Employment Type", ["Salaried", "Self-Employed"])
income_level = st.selectbox("Income Level", ["High", "Medium", "Low"])
collateral = st.selectbox("Collateral Available", ["Yes", "No"])

def predict_loan(credit_score, income_level, collateral):
    if credit_score == "Good":
        return " Approved"
    elif credit_score == "Poor":
        return " Rejected"
    elif credit_score == "Average":
        if collateral == "Yes":
            return " Approved"
        else:
            return " Possibly Rejected (Needs Review)"
    else:
        return "Unknown"

if st.button("Predict Loan Status"):
    result = predict_loan(credit_score, income_level, collateral)
    st.success(f"Prediction: **{result}**")
