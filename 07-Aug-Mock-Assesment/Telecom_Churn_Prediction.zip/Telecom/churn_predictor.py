import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, export_text

# Step 1: Create the DataFrame
data = {
    "Contract Type": ["Month-to-month", "Two year", "Month-to-month", "One year", "Month-to-month",
                      "Two year", "One year", "Month-to-month", "Two year", "One year"],
    "Support Calls": ["High", "Low", "High", "Medium", "Low",
                      "Low", "High", "Medium", "Low", "Low"],
    "Monthly Charges": ["High", "Low", "Medium", "Medium", "High",
                        "Low", "Medium", "High", "Low", "Medium"],
    "Internet Service": ["Yes", "No", "Yes", "No", "Yes",
                         "No", "Yes", "Yes", "No", "No"],
    "Churn": ["Yes", "No", "Yes", "No", "Yes",
              "No", "Yes", "Yes", "No", "No"]
}

df = pd.DataFrame(data)

# Step 2: Encode categorical variables
le = LabelEncoder()
df_encoded = df.apply(le.fit_transform)

# Step 3: Split features and target
X = df_encoded.drop("Churn", axis=1)
y = df_encoded["Churn"]

# Step 4: Train the ID3 Decision Tree
model = DecisionTreeClassifier(criterion="entropy", random_state=0)
model.fit(X, y)

# Step 5: Visualize the Tree (text-based)
feature_names = X.columns
tree_rules = export_text(model, feature_names=list(feature_names))
print(" ID3 Decision Tree Rules:\n")
print(tree_rules)
